<?php
return array(
'DB_HOST'=>'localhost',
'DB_NAME'=>'fanweo2o',
'DB_USER'=>'root',
'DB_PWD'=>'root',
'DB_PORT'=>'3306',
'DB_PREFIX'=>'fanwe_',
);
?>