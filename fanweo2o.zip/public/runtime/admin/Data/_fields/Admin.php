<?php
return array (
  0 => 'id',
  1 => 'adm_name',
  2 => 'adm_password',
  3 => 'is_effect',
  4 => 'is_delete',
  5 => 'role_id',
  6 => 'login_time',
  7 => 'login_ip',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>