<?php
return array (
  0 => 'id',
  1 => 'topic_count',
  2 => 'topic_count_time',
  3 => 'dp_count',
  4 => 'dp_count_time',
  5 => 'msg_count',
  6 => 'msg_count_time',
  7 => 'buy_msg_count',
  8 => 'buy_msg_count_time',
  9 => 'order_count',
  10 => 'order_count_time',
  11 => 'refund_count',
  12 => 'refund_count_time',
  13 => 'retake_count',
  14 => 'retake_count_time',
  15 => 'incharge_count',
  16 => 'incharge_count_time',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>