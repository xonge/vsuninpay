<?php
return array (
  0 => 'id',
  1 => 'income_money',
  2 => 'income_order',
  3 => 'income_incharge',
  4 => 'out_money',
  5 => 'out_uwd_money',
  6 => 'out_swd_money',
  7 => 'refund_money',
  8 => 'refund_cost_money',
  9 => 'sale_money',
  10 => 'sale_cost_money',
  11 => 'balance_money',
  12 => 'verify_money',
  13 => 'verify_cost_money',
  14 => 'stat_time',
  15 => 'stat_month',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>