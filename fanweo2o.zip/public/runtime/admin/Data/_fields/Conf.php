<?php
return array (
  0 => 'id',
  1 => 'name',
  2 => 'value',
  3 => 'group_id',
  4 => 'input_type',
  5 => 'value_scope',
  6 => 'is_effect',
  7 => 'is_conf',
  8 => 'sort',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>