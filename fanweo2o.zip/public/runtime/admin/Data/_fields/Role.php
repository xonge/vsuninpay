<?php
return array (
  0 => 'id',
  1 => 'name',
  2 => 'is_effect',
  3 => 'is_delete',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>