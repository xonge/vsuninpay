<?php
return array (
  0 => 'id',
  1 => 'code',
  2 => 'title',
  3 => 'val',
  4 => 'type',
  5 => 'group_name',
  6 => 'sort',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>