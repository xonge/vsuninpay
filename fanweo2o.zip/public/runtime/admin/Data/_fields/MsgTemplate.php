<?php
return array (
  0 => 'id',
  1 => 'name',
  2 => 'content',
  3 => 'type',
  4 => 'is_html',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>