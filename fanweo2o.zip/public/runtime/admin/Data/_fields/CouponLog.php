<?php
return array (
  0 => 'id',
  1 => 'coupon_sn',
  2 => 'create_time',
  3 => 'msg',
  4 => 'query_id',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>