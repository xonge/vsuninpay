<?php
return array (
  0 => 'id',
  1 => 'class_name',
  2 => 'name',
  3 => 'print_tmpl',
  4 => 'is_effect',
  5 => 'config',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>