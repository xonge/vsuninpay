<?php
return array (
  0 => 'id',
  1 => 'name',
  2 => 'uname',
  3 => 'is_effect',
  4 => 'is_delete',
  5 => 'pid',
  6 => 'is_open',
  7 => 'is_default',
  8 => 'description',
  9 => 'notice',
  10 => 'seo_title',
  11 => 'seo_keyword',
  12 => 'seo_description',
  13 => 'sort',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>