<?php
return array (
  0 => 'id',
  1 => 'name',
  2 => 'point',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>