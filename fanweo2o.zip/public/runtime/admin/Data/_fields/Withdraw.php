<?php
return array (
  0 => 'id',
  1 => 'user_id',
  2 => 'money',
  3 => 'create_time',
  4 => 'is_paid',
  5 => 'pay_time',
  6 => 'bank_name',
  7 => 'bank_account',
  8 => 'bank_user',
  9 => 'is_delete',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>