<?php
return array (
  0 => 'id',
  1 => 'log_info',
  2 => 'log_time',
  3 => 'log_admin',
  4 => 'log_ip',
  5 => 'log_status',
  6 => 'module',
  7 => 'action',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>