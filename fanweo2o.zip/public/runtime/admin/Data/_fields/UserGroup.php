<?php
return array (
  0 => 'id',
  1 => 'name',
  2 => 'score',
  3 => 'discount',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>