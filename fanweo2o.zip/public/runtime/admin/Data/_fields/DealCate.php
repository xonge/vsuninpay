<?php
return array (
  0 => 'id',
  1 => 'name',
  2 => 'brief',
  3 => 'pid',
  4 => 'is_delete',
  5 => 'is_effect',
  6 => 'sort',
  7 => 'uname',
  8 => 'recommend',
  9 => 'icon',
  10 => 'rec_youhui',
  11 => 'rec_daijin',
  12 => 'iconfont',
  13 => 'iconcolor',
  14 => 'icon_img',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>