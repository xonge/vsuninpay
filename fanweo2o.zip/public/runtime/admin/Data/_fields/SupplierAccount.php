<?php
return array (
  0 => 'id',
  1 => 'account_name',
  2 => 'account_password',
  3 => 'supplier_id',
  4 => 'is_effect',
  5 => 'is_delete',
  6 => 'description',
  7 => 'login_ip',
  8 => 'login_time',
  9 => 'update_time',
  10 => 'allow_delivery',
  11 => 'allow_charge',
  12 => 'is_main',
  13 => 'mobile',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>