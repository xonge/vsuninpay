<?php
//000000086400s:342:"<span style='display:inline-block; width:200px; height:44px; background:url(http://127.0.0.1/fanweo2o/public/attachment/201011/4cdd50ed013ec.png) no-repeat; _filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src=http://127.0.0.1/fanweo2o/public/attachment/201011/4cdd50ed013ec.png, sizingMethod=scale);_background-image:none;'></span>";
?>