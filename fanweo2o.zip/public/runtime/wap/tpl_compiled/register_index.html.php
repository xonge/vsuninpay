<?php echo $this->fetch('./inc/header.html'); ?>
<script>
<!--
/*第一种形式 第二种形式 更换显示样式*/
function setTab(name,cursel,n){
 for(i=1;i<=n;i++){
  var menu=document.getElementById(name+i);
  var con=document.getElementById("con_"+name+"_"+i);
  menu.className=i==cursel?"hover":"";
  con.style.display=i==cursel?"block":"none";
 }
}
//-->
</script>		
<div class="wrap">

	<div class="content">
	<div class="comment_list_txt">
		<form id="normal-register-form" action="<?php
echo parse_wap_url_tag("u:index|register|"."".""); 
?>" autocomplete="off" method="post" onsubmit="return check(this)">

		 <div class="Contentbox">  
				<div class="inputtxt">
				<div class="inputpc"><i class="fa fa-envelope"></i></div>	
				<div class="input_sr"><input type="text" placeholder="请输入邮箱" name="email" id="email"></div>
				</div>		   
				<div class="inputtxt">
				<div class="inputpc"><i class="fa fa-user"></i></div>	
				<div class="input_sr"><input type="text" placeholder="请输入昵称" name="user_name" id="user_name"></div>
				</div>
				<div class="inputtxt"> 
				<div class="inputpc"><i class="fa fa-lock"></i></div>
				<div class="input_sr"><input type="text" placeholder="请输入密码" name="pwd" id="pwd"></div>	 
				</div>
				<div class="inputtxt"> 
				<div class="inputpc"><i class="fa fa-lock"></i></div>
				<div class="input_sr"><input type="text" placeholder="请再次输入密码" name="ppwd" id="ppwd"></div>	 
				</div>
				<div class="inputtxt2 chk"> 
				<span class="chk_sp1">选择性别:</span>
				<input class="mt_sex" type="radio" name="sex" value="1" /><span class="chk_sp2">男</span>
				<input class="mt_sex" type="radio" name="sex" value="0"/><span class="chk_sp2">女</span>
				</div>
				<div class="btn_login">
				<?php if ($this->_var['ref_uid']): ?><input type="hidden" name="ref_uid" id="ref_uid" value="<?php echo $this->_var['ref_uid']; ?>"><?php endif; ?>
				<input  type="submit"  name="Submit" class="mj-submit" value="注册" 	style="background: none;">
				</div>
		 </div>
		            
		</form>
	 </div>
	</div>
</div>				
<script type="text/javascript">
function  check(){
	
	var obj1=$("#email").val();
	var obj2=$("#user_name").val();
	var obj3=$("#pwd").val();
	var obj4=$("#ppwd").val();
	var obj5=$("input[name='sex']:checked").val();
	var obj6=$("#ref_uid").val();
	var myreg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	if(!obj1){
		alert("请填写邮箱");
		return false;	
	}
	if(!myreg.test(obj1)){
	    alert('提示\n\n请输入有效的E_mail！');
	    return false;
	   }
	if(!obj2){
		alert("请填昵称");
		return false;
	}
	if(!obj3){
		alert("请填密码");
		return false;		
	}	
	if(!obj4){
		alert("请填确认密码");
		return false;		
	}
	if(!obj5){
		alert("选择性别");
		return false;		
	}
	if(obj3!=obj4){
		alert("两次密码不一致");
		return false;	
	}	
	var query = new Object();
	query.email = obj1;
	query.user_name = obj2;
	query.password=obj3;
	query.gender = obj5;
	query.ref_uid=obj6;
	query.post_type = "json";
	var ajaxurl = 	$("#normal-register-form").attr("action");
	$.ajax({
		url:ajaxurl,
		data:query,
		type:"post",
		dataType:"json",
		success:function(data){
			if(data.status==1){ 	
				alert(data.info);
				window.location.href="<?php
echo parse_wap_url_tag("u:index|user_center#index|"."".""); 
?>";
			}else{
				alert(data.info);
			}
		}
		,error:function(){
			alert("服务器提交错误");
		}
	});	
		return false;
	}
</script>					
<?php echo $this->fetch('./inc/footer.html'); ?> 