<?php 
return array(
	'APP_NAME'	=>	'方维商业系统  fanwe.com ',
	'APP_SUB_VER'	=>	2390,
);
?>