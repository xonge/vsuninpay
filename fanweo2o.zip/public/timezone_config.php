<?php
return array(
'DEFAULT_TIMEZONE'=>'PRC',
);
?>