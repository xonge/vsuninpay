<?php
//fwb add 2014-08-27
class more{
	public function index()
	{
		$root = array();
		$root['return']=1;
		$root['page_title']="更多";
		$root['f_link_data']=get_link_list();
		output($root);
	}
}
?>
