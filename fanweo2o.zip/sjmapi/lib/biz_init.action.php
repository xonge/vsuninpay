<?php
class biz_init{
	public function index()
	{
		$root = array();
		$root['return'] = 1;

		$root['kf_phone'] = $GLOBALS['m_config']['kf_phone'];//客服电话
		$root['kf_email'] = $GLOBALS['m_config']['kf_email'];//客服邮箱
		$root['about_id'] = 20;//$GLOBALS['m_config']['about_id'];//关于我们，对应的文章ID

		
		output($root);
	}
}
?>